#!/bin/bash

cd `dirname $0`

source colors
source h-manifest.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1

CUSTOM_LOG_BASEDIR=`dirname "${CUSTOM_LOG_BASENAME}"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

[[ -n "$GPU_LIST" ]] && export CUDA_VISIBLE_DEVICES="${GPU_LIST// /}"

CMD="./golden-miner-pool-prover --pubkey=$PUBKEY"

[[ -n "$PROXY" ]] && CMD="$CMD --proxy=$PROXY"
[[ -n "$LABEL" ]] && CMD="$CMD --label=$LABEL"
[[ -n "$NAME" ]] && CMD="$CMD --name=$NAME"
[[ -n "$THREADS_PER_CARD" ]] && CMD="$CMD --threads-per-card=$THREADS_PER_CARD"

$CMD 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
