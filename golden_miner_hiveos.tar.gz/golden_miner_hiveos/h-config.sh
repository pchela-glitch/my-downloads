#!/usr/bin/env bash

cd `dirname $0`

source /hive-config/rig.conf
rig_name="${WORKER_NAME}"
rig_id="${RIG_ID}"
farm_id="${FARM_ID}"

if [[ $CUSTOM_USER_CONFIG =~ --pubkey(=|[[:space:]]+)([^[:space:]]+) ]]; then
    USER_PUBKEY="${BASH_REMATCH[2]}"
fi

if [[ -z "$USER_PUBKEY" ]]; then
    echo "No pubkey found in custom user config"
    exit 1
fi

if [[ $CUSTOM_USER_CONFIG =~ --proxy(=|[[:space:]]+)([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:[0-9]+) ]]; then
    USER_PROXY="${BASH_REMATCH[2]}"
fi

if [[ $CUSTOM_USER_CONFIG =~ --label(=|[[:space:]]+)([^[:space:]]+) ]]; then
    USER_LABEL="${BASH_REMATCH[2]}"
fi

if [[ $CUSTOM_USER_CONFIG =~ --name(=|[[:space:]]+)([^[:space:]]+) ]]; then
    USER_NAME="${BASH_REMATCH[2]}"
fi

if [[ $CUSTOM_USER_CONFIG =~ --threads-per-card(=|[[:space:]]+)([0-9]+) ]]; then
    USER_THREADS_PER_CARD="${BASH_REMATCH[2]}"
fi

if [[ $CUSTOM_USER_CONFIG =~ --gpu(=|[[:space:]]+)([0-9]+(,[0-9]+)*) ]]; then
    USER_GPU_LIST="${BASH_REMATCH[2]}"
fi

if [[ -n "$USER_LABEL" ]]; then
    FINAL_LABEL="${farm_id}-${USER_LABEL}"
else
    FINAL_LABEL="$farm_id"
fi

if [[ -n "$USER_NAME" ]]; then
    FINAL_NAME="${rig_id}-${rig_name}-${USER_NAME}"
else
    FINAL_NAME="${rig_id}-${rig_name}"
fi

conf=""
conf+="PUBKEY=\"$USER_PUBKEY\""$'\n'
conf+="LABEL=\"$FINAL_LABEL\""$'\n'
conf+="NAME=\"$FINAL_NAME\""$'\n'
[[ -n "$USER_PROXY" ]] && conf+="PROXY=\"$USER_PROXY\""$'\n'
[[ -n "$USER_THREADS_PER_CARD" ]] && conf+="THREADS_PER_CARD=\"$USER_THREADS_PER_CARD\""$'\n'
[[ -n "$USER_GPU_LIST" ]] && conf+="GPU_LIST=\"$USER_GPU_LIST\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME
